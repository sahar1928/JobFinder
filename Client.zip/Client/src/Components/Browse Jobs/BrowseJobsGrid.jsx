import React from 'react'
import BrowseJob from './BrowseJob'

const BrowseJobsGrid = () => {
  return (
    <BrowseJob view={'grid'}/>
  )
}

export default BrowseJobsGrid