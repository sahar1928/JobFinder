import React from 'react'
import BrowseJob from './BrowseJob'

const BrowseJobsList = () => {
  return (
  <BrowseJob view={'list'}/>  
);
};

export default BrowseJobsList;
